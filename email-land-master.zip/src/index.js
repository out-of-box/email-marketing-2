// import $ from 'jquery';
import './css/main.css'
import './scss/main.scss'
import './js/calc.js'
import './js/common'
