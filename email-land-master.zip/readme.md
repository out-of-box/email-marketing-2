Сборка https://github.com/vedees/webpack-template
Видео https://www.youtube.com/watch?v=JcKRovPhGo8&list=PLkCrmfIT6LBQWN02hNj6r1daz7965GxsV
# email-marketing-2
